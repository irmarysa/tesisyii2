<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\PersonalDetalleSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Personal Detalles';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="personal-detalle-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Personal Detalle', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id_personal',
            'telefono',
            'direccion',
            'edo_civil',
            'correo',
            // 'fecha_registro',
            // 'fecha_egreso',
            // 'cargo',
            // 'tipo_personal',
            // 'nivel',
            // 'fecha_actualizacion',
            // 'id_dependencias',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
