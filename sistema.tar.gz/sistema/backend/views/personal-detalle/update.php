<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\PersonalDetalle */

$this->title = 'Update Personal Detalle: ' . ' ' . $model->id_personal;
$this->params['breadcrumbs'][] = ['label' => 'Personal Detalles', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_personal, 'url' => ['view', 'id_personal' => $model->id_personal, 'fecha_actualizacion' => $model->fecha_actualizacion]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="personal-detalle-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
