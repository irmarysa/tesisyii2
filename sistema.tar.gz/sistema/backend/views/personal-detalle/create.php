<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\PersonalDetalle */

$this->title = 'Create Personal Detalle';
$this->params['breadcrumbs'][] = ['label' => 'Personal Detalles', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="personal-detalle-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
