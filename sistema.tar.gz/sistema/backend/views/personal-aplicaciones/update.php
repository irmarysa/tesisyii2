<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\PersonalAplicaciones */

$this->title = 'Update Personal Aplicaciones: ' . ' ' . $model->id_personal;
$this->params['breadcrumbs'][] = ['label' => 'Personal Aplicaciones', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_personal, 'url' => ['view', 'id_personal' => $model->id_personal, 'id_aplicaciones' => $model->id_aplicaciones]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="personal-aplicaciones-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
