<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "int_personal_detalle".
 *
 * @property integer $id_personal
 * @property string $telefono
 * @property string $direccion
 * @property string $edo_civil
 * @property string $correo
 * @property string $fecha_registro
 * @property string $fecha_egreso
 * @property string $cargo
 * @property string $tipo_personal
 * @property string $nivel
 * @property string $fecha_actualizacion
 * @property integer $id_dependencias
 *
 * @property IntDependencias $idDependencias
 * @property IntPersonal $idPersonal
 */
class PersonalDetalle extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'int_personal_detalle';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_personal', 'fecha_actualizacion'], 'required'],
            [['id_personal', 'id_dependencias'], 'integer'],
            [['fecha_registro', 'fecha_egreso', 'fecha_actualizacion'], 'safe'],
            [['telefono', 'cargo', 'tipo_personal'], 'string', 'max' => 30],
            [['direccion', 'correo'], 'string', 'max' => 255],
            [['edo_civil', 'nivel'], 'string', 'max' => 20]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_personal' => 'Id Personal',
            'telefono' => 'Telefono',
            'direccion' => 'Direccion',
            'edo_civil' => 'Edo Civil',
            'correo' => 'Correo',
            'fecha_registro' => 'Fecha Registro',
            'fecha_egreso' => 'Fecha Egreso',
            'cargo' => 'Cargo',
            'tipo_personal' => 'Tipo Personal',
            'nivel' => 'Nivel',
            'fecha_actualizacion' => 'Fecha Actualizacion',
            'id_dependencias' => 'Id Dependencias',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdDependencias()
    {
        return $this->hasOne(IntDependencias::className(), ['id' => 'id_dependencias']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPersonal()
    {
        return $this->hasOne(IntPersonal::className(), ['id' => 'id_personal']);
    }

    /**
     * @inheritdoc
     * @return PersonalDetalleQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new PersonalDetalleQuery(get_called_class());
    }
}
