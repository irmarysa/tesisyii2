<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "int_personal_aplicaciones".
 *
 * @property integer $id_personal
 * @property integer $id_aplicaciones
 *
 * @property IntAplicaciones $idAplicaciones
 * @property IntPersonal $idPersonal
 */
class PersonalAplicaciones extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'int_personal_aplicaciones';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_personal', 'id_aplicaciones'], 'required'],
            [['id_personal', 'id_aplicaciones'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_personal' => 'Id Personal',
            'id_aplicaciones' => 'Id Aplicaciones',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdAplicaciones()
    {
        return $this->hasOne(IntAplicaciones::className(), ['id' => 'id_aplicaciones']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPersonal()
    {
        return $this->hasOne(IntPersonal::className(), ['id' => 'id_personal']);
    }

    /**
     * @inheritdoc
     * @return PersonalAplicacionesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new PersonalAplicacionesQuery(get_called_class());
    }
}
