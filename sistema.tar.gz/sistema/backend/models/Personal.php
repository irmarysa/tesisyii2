<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "int_personal".
 *
 * @property string $cedula
 * @property string $apellidos
 * @property string $nombres
 * @property integer $codigo_asistencia
 * @property string $id_usuario
 * @property integer $id
 * @property string $fecha_actualizacion
 * @property integer $activo
 *
 * @property IntPersonalAplicaciones[] $intPersonalAplicaciones
 * @property IntAplicaciones[] $idAplicaciones
 * @property IntPersonalDetalle[] $intPersonalDetalles
 */
class Personal extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'int_personal';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['codigo_asistencia', 'activo'], 'integer'],
            [['fecha_actualizacion'], 'safe'],
            [['cedula', 'id_usuario'], 'string', 'max' => 20],
            [['apellidos'], 'string', 'max' => 30],
            [['nombres'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'cedula' => 'Cedula',
            'apellidos' => 'Apellidos',
            'nombres' => 'Nombres',
            'codigo_asistencia' => 'Codigo Asistencia',
            'id_usuario' => 'Id Usuario',
            'id' => 'ID',
            'fecha_actualizacion' => 'Fecha Actualizacion',
            'activo' => 'Activo',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIntPersonalAplicaciones()
    {
        return $this->hasMany(IntPersonalAplicaciones::className(), ['id_personal' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdAplicaciones()
    {
        return $this->hasMany(IntAplicaciones::className(), ['id' => 'id_aplicaciones'])->viaTable('int_personal_aplicaciones', ['id_personal' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIntPersonalDetalles()
    {
        return $this->hasMany(IntPersonalDetalle::className(), ['id_personal' => 'id']);
    }

    /**
     * @inheritdoc
     * @return PersonalQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new PersonalQuery(get_called_class());
    }
}
