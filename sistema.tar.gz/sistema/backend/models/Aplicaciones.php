<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "int_aplicaciones".
 *
 * @property string $nombre
 * @property integer $id
 *
 * @property IntPersonalAplicaciones[] $intPersonalAplicaciones
 * @property IntPersonal[] $idPersonals
 */
class Aplicaciones extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'int_aplicaciones';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nombre'], 'string', 'max' => 30]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'nombre' => 'Nombre',
            'id' => 'ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIntPersonalAplicaciones()
    {
        return $this->hasMany(IntPersonalAplicaciones::className(), ['id_aplicaciones' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPersonals()
    {
        return $this->hasMany(IntPersonal::className(), ['id' => 'id_personal'])->viaTable('int_personal_aplicaciones', ['id_aplicaciones' => 'id']);
    }

    /**
     * @inheritdoc
     * @return AplicacionesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new AplicacionesQuery(get_called_class());
    }
}
