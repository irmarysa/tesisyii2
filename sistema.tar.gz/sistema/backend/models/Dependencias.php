<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "int_dependencias".
 *
 * @property string $codigo
 * @property string $nombre
 * @property string $fecha_creacion
 * @property integer $id
 * @property integer $activo
 *
 * @property IntPersonalDetalle[] $intPersonalDetalles
 */
class Dependencias extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'int_dependencias';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['fecha_creacion'], 'safe'],
            [['activo'], 'integer'],
            [['codigo'], 'string', 'max' => 15],
            [['nombre'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'codigo' => 'Codigo',
            'nombre' => 'Nombre',
            'fecha_creacion' => 'Fecha Creacion',
            'id' => 'ID',
            'activo' => 'Activo',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIntPersonalDetalles()
    {
        return $this->hasMany(IntPersonalDetalle::className(), ['id_dependencias' => 'id']);
    }

    /**
     * @inheritdoc
     * @return DependenciasQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new DependenciasQuery(get_called_class());
    }
}
