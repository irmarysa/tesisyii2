<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\PersonalDetalle;

/**
 * PersonalDetalleSearch represents the model behind the search form about `backend\models\PersonalDetalle`.
 */
class PersonalDetalleSearch extends PersonalDetalle
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_personal', 'id_dependencias'], 'integer'],
            [['telefono', 'direccion', 'edo_civil', 'correo', 'fecha_registro', 'fecha_egreso', 'cargo', 'tipo_personal', 'nivel', 'fecha_actualizacion'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = PersonalDetalle::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id_personal' => $this->id_personal,
            'fecha_registro' => $this->fecha_registro,
            'fecha_egreso' => $this->fecha_egreso,
            'fecha_actualizacion' => $this->fecha_actualizacion,
            'id_dependencias' => $this->id_dependencias,
        ]);

        $query->andFilterWhere(['like', 'telefono', $this->telefono])
            ->andFilterWhere(['like', 'direccion', $this->direccion])
            ->andFilterWhere(['like', 'edo_civil', $this->edo_civil])
            ->andFilterWhere(['like', 'correo', $this->correo])
            ->andFilterWhere(['like', 'cargo', $this->cargo])
            ->andFilterWhere(['like', 'tipo_personal', $this->tipo_personal])
            ->andFilterWhere(['like', 'nivel', $this->nivel]);

        return $dataProvider;
    }
}
