<?php

namespace backend\controllers;

use Yii;
use backend\models\PersonalAplicaciones;
use backend\models\PersonalAplicacionesSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * PersonalAplicacionesController implements the CRUD actions for PersonalAplicaciones model.
 */
class PersonalAplicacionesController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all PersonalAplicaciones models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PersonalAplicacionesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single PersonalAplicaciones model.
     * @param integer $id_personal
     * @param integer $id_aplicaciones
     * @return mixed
     */
    public function actionView($id_personal, $id_aplicaciones)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_personal, $id_aplicaciones),
        ]);
    }

    /**
     * Creates a new PersonalAplicaciones model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new PersonalAplicaciones();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_personal' => $model->id_personal, 'id_aplicaciones' => $model->id_aplicaciones]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing PersonalAplicaciones model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id_personal
     * @param integer $id_aplicaciones
     * @return mixed
     */
    public function actionUpdate($id_personal, $id_aplicaciones)
    {
        $model = $this->findModel($id_personal, $id_aplicaciones);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_personal' => $model->id_personal, 'id_aplicaciones' => $model->id_aplicaciones]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing PersonalAplicaciones model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id_personal
     * @param integer $id_aplicaciones
     * @return mixed
     */
    public function actionDelete($id_personal, $id_aplicaciones)
    {
        $this->findModel($id_personal, $id_aplicaciones)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the PersonalAplicaciones model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id_personal
     * @param integer $id_aplicaciones
     * @return PersonalAplicaciones the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_personal, $id_aplicaciones)
    {
        if (($model = PersonalAplicaciones::findOne(['id_personal' => $id_personal, 'id_aplicaciones' => $id_aplicaciones])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
