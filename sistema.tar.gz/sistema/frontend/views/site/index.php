<?php

/* @var $this yii\web\View */

$this->title = 'FUNDACITE';
?>
<div class="site-index">
<div align="center"><img src="ima.jpg" width="900" height="180" ></div>
    <div class="jumbotron">
        <h1>Bienvenidos a la Intranet!</h1>

        <p  class="lead">Sistema de Informaci&oacute;n Automatizado</p> 

      

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>FUNDACITE M&eacute;rida</h2>

                <p>La fundación de ciencia y tecnología cuenta con una Suite....</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/doc/">Ir a la p&aacute;gina &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Unidad de Sistemas</h2>

                <p>El departamento de la Unidad de sistemas se encarga de brindar el soporte técnico, asesoria a entes p&uacute;blicos...</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/forum/">Ir a la Wiki &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Suite de la Intranet</h2>

                <p>La novedosa aplicación se ha creado bajo el marco de trabajo YII2 ...........
                ....................</p>

            </div>
        </div>

    </div>
</div>
