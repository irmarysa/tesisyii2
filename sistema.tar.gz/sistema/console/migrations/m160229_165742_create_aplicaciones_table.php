<?php

use yii\db\Schema;
use yii\db\Migration;

class m160229_165742_create_aplicaciones_table extends Migration
{
    protected $tableName = 'aplicaciones';

    public function up()
    {
        $this->createTable($this->tableName, [
            'id' => $this->primaryKey(),
            'nombre' => $this->string(30)->notNull()
        ]);
    }

    public function down()
    {
        echo "m160229_165742_create_aplicaciones_table cannot be reverted.\n";
        return false;
    }
}
