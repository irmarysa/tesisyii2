<?php

use yii\db\Migration;

class m160229_165604_create_dependencias_table extends Migration
{
    protected $tableName = 'dependencias';

    /**
     * Crear la tabla, columnas y los indices y llaves foraneas necesarias
     *
     * @author Irmarys
     */
    public function up()
    {
        $this->createTable($this->tableName, [
               'id' => $this->primaryKey(),
            'codigo' => $this->string(15)->notNull(),
            'nombre' => $this->string(30)->notNull(),
             'activo' => $this->integer()->notNull(),
            'fecha_creacion' => $this->date()->notNull()
        ]);
    }

    public function down()
    {
        echo "m160229_165752_create_dependencias_table cannot be reverted.\n";
        return false;
    }
}
