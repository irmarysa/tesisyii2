<?php

use yii\db\Schema;
use yii\db\Migration;

class m160229_164603_create_personal_table extends Migration
{
    public function up()
    {
          $this->createTable("personal", [
             'id' => $this->primaryKey(),
             'cedula' => $this->string(20)->notNull(),
             'apellidos' => $this->string(30)->notNull(),
             'nombres' => $this->string(45)->notNull(),
             'activo' => $this->integer()->notNull(),
             'codigo_asistencia' => $this->integer()->notNull(),
             'id_usuario' => $this->string(20)->notNull(),
             'fecha_actualizacion' => $this->date()
          ]);
    }
  
    public function down()
    {
        $this->dropTable("personal");
    }
}
