<?php

use yii\db\Schema;
use yii\db\Migration;

class m160229_165607_create_personal_detalle_table extends Migration
{
    public $tableName = 'personal_detalle';

    /**
     *
     */
    public function up()
    {
        $this->createTable($this->tableName, [
            'id_personal' => $this->integer()->notNull(),
            'telefono' => $this->string(30)->notNull(),
            'direccion' => $this->string(255)->notNull(),
            'edo_civil' => $this->string(20)->notNull(),
            'correo' => $this->string(255)->notNull(),
            'fecha_registro' => $this->date()->notNull(),
            'fecha_egreso' => $this->date()->notNull(),
            'cargo' => $this->string(30)->notNull(),
            'tipo_personal' => $this->string(20)->notNull(),
            'nivel' => $this->string(30)->notNull(),
            'fecha_actualizacion' => $this->date()->notNull(),
            'id_dependencias' => $this->integer()->notNull()
        ]);

        $nameForeignKey = 'fk_'. $this->tableName . 'dependencias_id';
        $this->addForeignKey($nameForeignKey, $this->tableName,
            'id_dependencias', 'dependencias', 'id');

        $nameForeignKey = 'fk_'. $this->tableName . 'personal_id';
        $this->addForeignKey($nameForeignKey, $this->tableName,
            'id_personal', 'personal', 'id');
    }
  
    public function down()
    {
        $this->dropTable($this->tableName);
    }
}