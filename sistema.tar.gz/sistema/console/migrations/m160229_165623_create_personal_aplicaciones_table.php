<?php

use yii\db\Schema;
use yii\db\Migration;

class m160229_165623_create_personal_aplicaciones_table extends Migration
{

    public $tableName = 'personal_aplicaciones';

    public function up()
    {
        $this->createTable("personal_aplicaciones", [
            'id_personal' => $this->integer()->notNull(),
            'id_dependencias' => $this->integer()->notNull()
        ]);

        $this->createIndex('idx-personal_aplicaciones-id_personal', $this->tableName, 'id_personal');
        $this->createIndex('idx-personal_aplicaciones-id_dependencias', $this->tableName, 'id_dependencias');

        /**
         *
         */
        $this->addForeignKey('fk-'. $this->tableName . 'id_personal',
            $this->tableName, 'id_personal', 'personal', 'id');
        $this->addForeignKey('fk-'. $this->tableName . 'id_dependencias',
            $this->tableName, 'id_dependencias', 'dependencias', 'id');
    }

    public function down()
    {
        $this->dropTable($this->tableName);
    }
}
